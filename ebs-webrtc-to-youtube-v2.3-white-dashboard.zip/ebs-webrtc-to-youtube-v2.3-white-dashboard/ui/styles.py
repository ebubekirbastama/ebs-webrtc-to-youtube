APP_QSS = r'''
* {
    font-family: "Segoe UI";
    font-size: 10pt;
    color: #151922;
}
QMainWindow, QWidget#Root, QWidget#ScrollContent {
    background: #ffffff;
}
QScrollArea { border: 0; background: #ffffff; }
QScrollArea > QWidget > QWidget { background: #ffffff; }

QFrame#Card {
    background: #ffffff;
    border: 1px solid #d9dee7;
    border-radius: 16px;
}
QWidget#HeaderFrame {
    background: #ffffff;
    border: 0;
    border-bottom: 1px solid #e6e9ef;
}
QWidget#InfoBar {
    background: #eef7ff;
    border: 1px solid #b8dcff;
    border-radius: 9px;
}
QWidget#StatusBarFrame {
    background: #ffffff;
    border: 1px solid #e3e7ed;
    border-radius: 13px;
}
QWidget#BottomBar {
    background: #ffffff;
    border: 0;
    border-top: 1px solid #edf0f4;
}

QLabel#AppTitle { font-size: 20pt; font-weight: 800; color: #11151b; }
QLabel#AppSubTitle { font-size: 11pt; color: #667085; }
QLabel#CardTitle { font-size: 11.5pt; font-weight: 800; color: #161b23; }
QLabel#FieldLabel { font-size: 9.5pt; font-weight: 700; color: #202632; }
QLabel#Hint { color: #5c6675; }
QLabel#InfoText { color: #155a94; }
QLabel#DangerText { color: #ef4444; font-weight: 700; }
QLabel#Muted { color: #667085; }
QLabel#FooterText { color: #4f5967; font-size: 9pt; }
QLabel#DotIdle { color: #7a8491; }
QLabel#DotOk { color: #10a36a; }
QLabel#DotBad { color: #ef4444; }

QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
    background: #ffffff;
    color: #202632;
    border: 1px solid #d8dee8;
    border-radius: 9px;
    padding: 8px 10px;
    selection-background-color: #dcecff;
    selection-color: #1c2735;
}
QLineEdit:hover, QTextEdit:hover, QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover {
    border-color: #bfc8d5;
}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {
    border: 1px solid #4f8cff;
}
QTextEdit { padding: 10px; }
QComboBox { min-height: 20px; }
QComboBox::drop-down { border: 0; width: 26px; }
QComboBox QAbstractItemView {
    background: #ffffff;
    color: #202632;
    border: 1px solid #d8dee8;
    selection-background-color: #eef5ff;
    selection-color: #202632;
    outline: 0;
}

QPushButton {
    background: #ffffff;
    color: #344054;
    border: 1px solid #d0d5dd;
    border-radius: 9px;
    min-height: 36px;
    padding: 0 14px;
    font-weight: 800;
}
QPushButton:hover { background: #f8fafc; border-color: #98a2b3; }
QPushButton:pressed { background: #f1f4f7; padding-top: 2px; }
QPushButton:disabled { color: #d1d5db; background: #fbfbfc; border-color: #eceff3; }

QPushButton#Blue { color: #2474e5; border: 1px solid #4d90ff; background: #ffffff; }
QPushButton#Blue:hover { background: #f2f7ff; }
QPushButton#Green { color: #159a5f; border: 1px solid #63d19a; background: #f5fff9; }
QPushButton#Green:hover { background: #ecfff4; }
QPushButton#Red { color: #ff4f4f; border: 1px solid #ff6767; background: #fffafa; }
QPushButton#Red:hover { background: #fff1f1; }
QPushButton#Purple { color: #6f35db; border: 1px solid #864af2; background: #ffffff; }
QPushButton#Purple:hover { background: #f8f3ff; }
QPushButton#Orange { color: #d97706; border: 1px solid #f2a94f; background: #fffaf3; }
QPushButton#Orange:hover { background: #fff3df; }
QPushButton#Grey { color: #4f5967; border: 1px solid #d4dae3; background: #ffffff; }

QLabel#StatusOk {
    background: #effcf5;
    color: #0c965d;
    border: 1px solid #9be1bd;
    border-radius: 10px;
    padding: 10px 15px;
    font-weight: 800;
}
QLabel#StatusIdle {
    background: #f8fafc;
    color: #667085;
    border: 1px solid #d8dee8;
    border-radius: 10px;
    padding: 10px 15px;
    font-weight: 800;
}
QLabel#StatusBad {
    background: #fff4f4;
    color: #d92d20;
    border: 1px solid #f4b7b3;
    border-radius: 10px;
    padding: 10px 15px;
    font-weight: 800;
}

QRadioButton { spacing: 8px; color: #202632; }
QRadioButton::indicator { width: 17px; height: 17px; }
QRadioButton::indicator:unchecked {
    border: 1px solid #9aa4b2; border-radius: 9px; background: #ffffff;
}
QRadioButton::indicator:checked {
    border: 5px solid #753de0; border-radius: 9px; background: #ffffff;
}

QCheckBox#Toggle { spacing: 8px; }
QCheckBox#Toggle::indicator {
    width: 38px; height: 20px; border-radius: 10px;
}
QCheckBox#Toggle::indicator:unchecked {
    background: #d9dee6; border: 1px solid #c6ccd5;
}
QCheckBox#Toggle::indicator:checked {
    background: #7338dd; border: 1px solid #7338dd;
}
QCheckBox { spacing: 7px; }

QSlider::groove:horizontal {
    height: 5px; background: #e9edf2; border-radius: 2px;
}
QSlider::sub-page:horizontal { background: #7436d8; border-radius: 2px; }
QSlider::handle:horizontal {
    background: #ffffff; border: 1px solid #7436d8; width: 12px; height: 12px;
    margin: -4px 0; border-radius: 6px;
}

QDialog, QMessageBox, QInputDialog, QFileDialog {
    background: #ffffff;
    color: #202632;
}
QMessageBox QLabel, QInputDialog QLabel, QFileDialog QLabel {
    background: transparent;
    color: #202632;
}
QMessageBox QPushButton, QDialog QPushButton {
    color: #344054;
    background: #ffffff;
    border: 1px solid #cfd6df;
    min-width: 82px;
}
QMessageBox QPushButton:hover, QDialog QPushButton:hover {
    background: #f7f9fb;
    border-color: #98a2b3;
}
QMenu { background:#ffffff; color:#202632; border:1px solid #d7dde5; padding:5px; }
QMenu::item { background:#ffffff; color:#202632; padding:7px 22px 7px 10px; }
QMenu::item:selected { background:#eef5ff; color:#202632; }
QToolTip { background:#ffffff; color:#202632; border:1px solid #cfd6df; padding:5px; }
QAbstractItemView { background:#ffffff; color:#202632; selection-background-color:#eef5ff; selection-color:#202632; }
QScrollBar:vertical, QScrollBar:horizontal { background:#f5f7f9; border:0; }
QScrollBar::handle:vertical, QScrollBar::handle:horizontal { background:#c6cdd6; border-radius:5px; min-height:24px; min-width:24px; }
'''
