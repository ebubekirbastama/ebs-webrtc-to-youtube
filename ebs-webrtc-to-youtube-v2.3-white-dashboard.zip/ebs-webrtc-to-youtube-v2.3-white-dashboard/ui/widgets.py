from PySide6.QtCore import Qt
from PySide6.QtGui import QCursor
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QPushButton


class Card(QFrame):
    def __init__(self, title='', icon='', parent=None):
        super().__init__(parent)
        self.setObjectName('Card')
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 15, 16, 16)
        lay.setSpacing(10)
        self.body = lay
        if title:
            t = QLabel((icon + '  ' if icon else '') + title)
            t.setObjectName('CardTitle')
            lay.addWidget(t)


class ActionButton(QPushButton):
    def __init__(self, text, kind='Blue', parent=None):
        super().__init__(text, parent)
        self.setObjectName(kind)
        self.setCursor(QCursor(Qt.PointingHandCursor))


class StatusLabel(QLabel):
    def set_state(self, state, text):
        self.setText(text)
        self.setObjectName({'ok': 'StatusOk', 'bad': 'StatusBad'}.get(state, 'StatusIdle'))
        style = self.style()
        if style:
            style.unpolish(self)
            style.polish(self)
        self.update()
