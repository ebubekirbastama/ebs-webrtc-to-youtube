from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QObject, QThread, Signal, Qt
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QTextEdit, QComboBox, QCheckBox, QSpinBox, QDoubleSpinBox,
    QFileDialog, QMessageBox, QScrollArea, QInputDialog, QRadioButton, QButtonGroup,
    QSlider, QDialog, QFormLayout
)

from .widgets import Card, ActionButton, StatusLabel
from core.process_manager import BridgeProcess
from core.settings import load_settings, save_settings
from bootstrap import find_ffmpeg, try_install_ffmpeg_windows
from youtube.api import YouTubeLive
from youtube.auth import disconnect, SECRET, TOKEN

ROOT = Path(__file__).resolve().parents[1]


class Worker(QObject):
    done = Signal(object)
    fail = Signal(str)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn())
        except Exception as exc:
            self.fail.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.s = load_settings()
        self.yt = None
        self.bridge = BridgeProcess(self)
        self.answer = ''
        self.setWindowTitle('EBS WebRTC → YouTube Live')
        self.resize(1536, 1024)
        self.setMinimumSize(1120, 760)
        if (ROOT / 'logo.png').is_file():
            self.setWindowIcon(QIcon(str(ROOT / 'logo.png')))

        self.bridge.log.connect(self.log)
        self.bridge.answer.connect(self._answer)
        self.bridge.state.connect(self._bridge_state)

        self._build()
        self._load()
        self._check_ffmpeg()
        self._refresh_secret_state()
        self.log('[INFO] Sistem başlatıldı...')
        self.log('[INFO] Ayarlar yüklendi')
        self._sync_mode_log()

    def _build(self):
        root = QWidget()
        root.setObjectName('Root')
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        wrap = QWidget()
        wrap.setObjectName('ScrollContent')
        lay = QVBoxLayout(wrap)
        lay.setContentsMargins(20, 18, 20, 12)
        lay.setSpacing(14)

        # Header
        header = QWidget()
        header.setObjectName('HeaderFrame')
        hr = QHBoxLayout(header)
        hr.setContentsMargins(8, 4, 4, 12)
        hr.setSpacing(18)

        logo = QLabel()
        logo.setFixedSize(82, 82)
        logo.setAlignment(Qt.AlignCenter)
        logo_path = ROOT / 'logo.png'
        if logo_path.is_file():
            pix = QPixmap(str(logo_path))
            if not pix.isNull():
                logo.setPixmap(pix.scaled(78, 78, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        hr.addWidget(logo)

        title_box = QVBoxLayout()
        title_box.setSpacing(4)
        title = QLabel('EBS WebRTC → YouTube Live')
        title.setObjectName('AppTitle')
        sub = QLabel('Professional live relay console')
        sub.setObjectName('AppSubTitle')
        title_box.addStretch()
        title_box.addWidget(title)
        title_box.addWidget(sub)
        title_box.addStretch()
        hr.addLayout(title_box)
        hr.addStretch()

        self.sysstatus = StatusLabel()
        self.sysstatus.set_state('idle', '●  SİSTEM KONTROL')
        hr.addWidget(self.sysstatus)
        lay.addWidget(header)

        # Top two cards
        top_grid = QGridLayout()
        top_grid.setHorizontalSpacing(16)
        top_grid.setVerticalSpacing(14)

        web = Card('1) WEBRTC GİRİŞ', '⛓')
        hint = QLabel('Yayıncıdan gelen Offer / davet kodunu girin:')
        hint.setObjectName('Hint')
        web.body.addWidget(hint)
        self.offer = QTextEdit()
        self.offer.setPlaceholderText('Offer / davet kodunu buraya yapıştırın...')
        self.offer.setMinimumHeight(112)
        self.offer.setMaximumHeight(150)
        web.body.addWidget(self.offer)
        wr = QHBoxLayout()
        clear = ActionButton('🧹  TEMİZLE', 'Blue')
        clear.clicked.connect(self.offer.clear)
        self.connect_btn = ActionButton('🔗  WEBRTC’YE BAĞLAN', 'Green')
        self.connect_btn.clicked.connect(self.start_bridge)
        wr.addWidget(clear)
        wr.addStretch()
        wr.addWidget(self.connect_btn)
        web.body.addLayout(wr)
        top_grid.addWidget(web, 0, 0)

        yt = Card('2) YOUTUBE (RTMP HEDEFİ)', '▶')
        mode_label = QLabel('RTMP Modu')
        mode_label.setObjectName('FieldLabel')
        yt.body.addWidget(mode_label)
        mode_row = QHBoxLayout()
        self.manual_radio = QRadioButton('Manuel RTMP')
        self.api_radio = QRadioButton('YouTube API (Otomatik)')
        self.mode_group = QButtonGroup(self)
        self.mode_group.addButton(self.manual_radio, 0)
        self.mode_group.addButton(self.api_radio, 1)
        self.manual_radio.setChecked(True)
        self.manual_radio.toggled.connect(self._mode_changed)
        self.api_radio.toggled.connect(self._mode_changed)
        mode_row.addWidget(self.manual_radio)
        mode_row.addSpacing(28)
        mode_row.addWidget(self.api_radio)
        mode_row.addStretch()
        yt.body.addLayout(mode_row)

        account_row = QHBoxLayout()
        account_box = QVBoxLayout()
        ac_title = QLabel('Hesap Durumu:')
        ac_title.setObjectName('FieldLabel')
        self.ytstatus = QLabel('Bağlı değil')
        self.ytstatus.setObjectName('DangerText')
        account_box.addWidget(ac_title)
        account_box.addWidget(self.ytstatus)
        account_row.addLayout(account_box)
        account_row.addStretch()
        auth = ActionButton('↗  YOUTUBE’A BAĞLAN', 'Purple')
        auth.clicked.connect(self.youtube_connect)
        account_row.addWidget(auth)
        yt.body.addLayout(account_row)

        rt_label = QLabel('RTMP / Stream Key')
        rt_label.setObjectName('FieldLabel')
        yt.body.addWidget(rt_label)
        rtmp_row = QHBoxLayout()
        self.rtmp = QLineEdit()
        self.rtmp.setPlaceholderText('RTMP URL veya Stream Key')
        self.rtmp.setEchoMode(QLineEdit.Password)
        rtmp_row.addWidget(self.rtmp, 1)
        show = ActionButton('◉', 'Grey')
        show.setFixedWidth(48)
        show.setToolTip('Göster / gizle')
        show.clicked.connect(self._toggle_rtmp_visibility)
        copy_rtmp = ActionButton('KOPYALA', 'Blue')
        copy_rtmp.clicked.connect(lambda: QApplication.clipboard().setText(self.rtmp.text()))
        rtmp_row.addWidget(show)
        rtmp_row.addWidget(copy_rtmp)
        yt.body.addLayout(rtmp_row)

        yb = QHBoxLayout()
        fetch = ActionButton('MEVCUT YAYINLARI GETİR', 'Blue')
        fetch.clicked.connect(self.youtube_fetch)
        create = ActionButton('♬  YENİ YAYIN OLUŞTUR', 'Purple')
        create.clicked.connect(self.youtube_create)
        yb.addWidget(fetch)
        yb.addStretch()
        yb.addWidget(create)
        yt.body.addLayout(yb)
        top_grid.addWidget(yt, 0, 1)
        top_grid.setColumnStretch(0, 1)
        top_grid.setColumnStretch(1, 1)
        lay.addLayout(top_grid)

        # Settings card
        settings = Card('3) YAYIN AYARLARI', '⚙')
        sg = QGridLayout()
        sg.setHorizontalSpacing(18)
        sg.setVerticalSpacing(6)

        self.res = QComboBox()
        self.res.addItems(['1920x1080 (16:9)', '1280x720 (16:9)', '854x480 (16:9)'])
        self.fps = QComboBox()
        self.fps.addItems(['30', '60'])
        self.bitrate = QComboBox()
        self.bitrate.setEditable(True)
        self.bitrate.addItems(['4500k', '5500k', '6500k', '8000k'])
        self.audio_bitrate = QComboBox()
        self.audio_bitrate.setEditable(True)
        self.audio_bitrate.addItems(['96k', '128k', '160k', '192k'])
        self.logo_toggle = QCheckBox()
        self.logo_toggle.setObjectName('Toggle')
        self.logo_toggle.setChecked(True)
        self.logo_toggle.toggled.connect(self._logo_toggle_changed)
        self.pos = QComboBox()
        self.pos.addItem('Sağ Üst', 'top-right')
        self.pos.addItem('Sol Üst', 'top-left')
        self.pos.addItem('Sağ Alt', 'bottom-right')
        self.pos.addItem('Sol Alt', 'bottom-left')
        self.opacity_slider = QSlider(Qt.Horizontal)
        self.opacity_slider.setRange(10, 100)
        self.opacity_slider.setValue(80)
        self.opacity_value = QLabel('80 %')
        self.opacity_value.setMinimumWidth(45)
        self.opacity_slider.valueChanged.connect(lambda v: self.opacity_value.setText(f'{v} %'))

        fields = [
            ('Çözünürlük', self.res), ('FPS', self.fps), ('Video Bitrate', self.bitrate),
            ('Audio Bitrate', self.audio_bitrate), ('Logo', self.logo_toggle), ('Logo Konumu', self.pos)
        ]
        for i, (lab, widget) in enumerate(fields):
            labw = QLabel(lab)
            labw.setObjectName('FieldLabel')
            sg.addWidget(labw, 0, i)
            sg.addWidget(widget, 1, i)

        op_lab = QLabel('Logo Opacity')
        op_lab.setObjectName('FieldLabel')
        sg.addWidget(op_lab, 0, 6)
        op_row = QHBoxLayout()
        op_row.addWidget(self.opacity_slider, 1)
        op_row.addWidget(self.opacity_value)
        sg.addLayout(op_row, 1, 6)

        logo_pick = ActionButton('LOGO SEÇ', 'Blue')
        logo_pick.clicked.connect(self.pick_logo)
        sg.addWidget(logo_pick, 1, 7)
        settings.body.addLayout(sg)

        info_bar = QWidget()
        info_bar.setObjectName('InfoBar')
        ib = QHBoxLayout(info_bar)
        ib.setContentsMargins(14, 8, 14, 8)
        info_icon = QLabel('●')
        info_icon.setStyleSheet('color:#1976d2; font-size:14pt;')
        self.logo_info = QLabel('Yayın logosu dosyası: logo.png (Proje ana klasörü)')
        self.logo_info.setObjectName('InfoText')
        ib.addWidget(info_icon)
        ib.addWidget(self.logo_info)
        ib.addStretch()
        settings.body.addWidget(info_bar)
        lay.addWidget(settings)

        # Hidden/advanced operational values kept intact
        self.logo = QLineEdit(str(ROOT / 'logo.png'))
        self.logo.hide()
        self.ffmpeg = QLineEdit()
        self.ffmpeg.hide()
        self.maxrate = QLineEdit()
        self.maxrate.hide()
        self.bufsize = QLineEdit()
        self.bufsize.hide()
        self.logo_w = QSpinBox()
        self.logo_w.setRange(50, 800)
        self.logo_w.hide()
        self.opacity = QDoubleSpinBox()
        self.opacity.setRange(.1, 1.0)
        self.opacity.hide()
        self.reencode = QCheckBox()
        self.reencode.hide()

        # Answer + logs
        bottom_grid = QGridLayout()
        bottom_grid.setHorizontalSpacing(16)
        bottom_grid.setVerticalSpacing(14)

        ans = Card('4) ANSWER (YAYINCIYA GÖNDER)', '➤')
        ah = QLabel('Oluşturulan Answer kodu burada görünecek.')
        ah.setObjectName('Hint')
        ans.body.addWidget(ah)
        self.answerbox = QTextEdit()
        self.answerbox.setReadOnly(True)
        self.answerbox.setPlaceholderText('Answer kodu oluştuğunda buraya gelecek...')
        self.answerbox.setMinimumHeight(90)
        ans.body.addWidget(self.answerbox)
        cp = ActionButton('▣  ANSWER KOPYALA', 'Blue')
        cp.clicked.connect(lambda: QApplication.clipboard().setText(self.answerbox.toPlainText()))
        ar = QHBoxLayout()
        ar.addWidget(cp)
        ar.addStretch()
        ans.body.addLayout(ar)
        bottom_grid.addWidget(ans, 0, 0)

        logc = Card('5) CANLI LOG', '☷')
        self.logbox = QTextEdit()
        self.logbox.setReadOnly(True)
        self.logbox.setMinimumHeight(116)
        logc.body.addWidget(self.logbox)
        lr = QHBoxLayout()
        lr.addStretch()
        clear_log = ActionButton('♲  LOGU TEMİZLE', 'Red')
        clear_log.clicked.connect(self.logbox.clear)
        lr.addWidget(clear_log)
        logc.body.addLayout(lr)
        bottom_grid.addWidget(logc, 0, 1)
        bottom_grid.setColumnStretch(0, 1)
        bottom_grid.setColumnStretch(1, 1)
        lay.addLayout(bottom_grid)

        # Runtime status/actions
        status_frame = QWidget()
        status_frame.setObjectName('StatusBarFrame')
        sf = QHBoxLayout(status_frame)
        sf.setContentsMargins(16, 8, 16, 8)
        sf.setSpacing(28)
        self.wstatus = QLabel('●  WebRTC: Bekliyor')
        self.wstatus.setObjectName('DotIdle')
        self.youtube_footer = QLabel('●  YouTube: Bekliyor')
        self.youtube_footer.setObjectName('DotIdle')
        self.ffmpeg_footer = QLabel('●  FFmpeg: Bekliyor')
        self.ffmpeg_footer.setObjectName('DotIdle')
        sf.addWidget(self.wstatus)
        sf.addWidget(self.youtube_footer)
        sf.addWidget(self.ffmpeg_footer)
        sf.addStretch()
        self.start_btn = ActionButton('▷  YAYINI BAŞLAT', 'Green')
        self.start_btn.clicked.connect(self.start_bridge)
        self.stop_btn = ActionButton('■  YAYINI DURDUR', 'Red')
        self.stop_btn.clicked.connect(self.bridge.stop)
        sf.addWidget(self.start_btn)
        sf.addWidget(self.stop_btn)
        lay.addWidget(status_frame)

        # Footer
        footer = QWidget()
        footer.setObjectName('BottomBar')
        fr = QHBoxLayout(footer)
        fr.setContentsMargins(4, 5, 4, 0)
        ver = QLabel('v2.3.0   |   EBS WebRTC → YouTube Live')
        ver.setObjectName('FooterText')
        fr.addWidget(ver)
        fr.addStretch()
        settings_btn = ActionButton('⚙  AYARLAR', 'Grey')
        settings_btn.clicked.connect(self.open_advanced_settings)
        about_btn = ActionButton('ⓘ  HAKKINDA', 'Grey')
        about_btn.clicked.connect(lambda: self.info('Hakkında', 'EBS WebRTC → YouTube Live\nWebRTC yayınlarını YouTube RTMP/RTMPS hedefine aktarır.'))
        fr.addWidget(settings_btn)
        fr.addWidget(about_btn)
        lay.addWidget(footer)

        scroll.setWidget(wrap)
        outer.addWidget(scroll)
        self.setCentralWidget(root)

    # ---------- dialog helpers ----------
    def _message(self, icon, title, text):
        box = QMessageBox(self)
        box.setIcon(icon)
        box.setWindowTitle(title)
        box.setText(text)
        box.setStandardButtons(QMessageBox.Ok)
        return box.exec()

    def warn(self, title, text): return self._message(QMessageBox.Warning, title, text)
    def error(self, title, text): return self._message(QMessageBox.Critical, title, text)
    def info(self, title, text): return self._message(QMessageBox.Information, title, text)

    def open_advanced_settings(self):
        dlg = QDialog(self)
        dlg.setWindowTitle('Gelişmiş Ayarlar')
        dlg.setMinimumWidth(620)
        root = QVBoxLayout(dlg)
        form = QFormLayout()

        ff_row = QHBoxLayout()
        ff_edit = QLineEdit(self.ffmpeg.text())
        ff_pick = ActionButton('SEÇ', 'Blue')
        ff_auto = ActionButton('OTOMATİK KUR', 'Orange')
        ff_row.addWidget(ff_edit, 1)
        ff_row.addWidget(ff_pick)
        ff_row.addWidget(ff_auto)
        form.addRow('FFmpeg:', ff_row)

        max_edit = QLineEdit(self.maxrate.text())
        buf_edit = QLineEdit(self.bufsize.text())
        logo_width = QSpinBox()
        logo_width.setRange(50, 800)
        logo_width.setValue(self.logo_w.value())
        reencode = QCheckBox('H.264 yeniden encode')
        reencode.setChecked(self.reencode.isChecked())
        form.addRow('Maxrate:', max_edit)
        form.addRow('Bufsize:', buf_edit)
        form.addRow('Logo genişliği:', logo_width)
        form.addRow('', reencode)
        root.addLayout(form)

        secret_line = QLabel(self.secret_label_text())
        secret_line.setObjectName('Muted')
        root.addWidget(secret_line)
        secret_row = QHBoxLayout()
        secret_pick = ActionButton('CLIENT_SECRET SEÇ', 'Blue')
        secret_pick.clicked.connect(lambda: (self.pick_client_secret(), secret_line.setText(self.secret_label_text())))
        secret_disconnect = ActionButton('YOUTUBE BAĞLANTISINI SİL', 'Red')
        secret_disconnect.clicked.connect(lambda: (self.youtube_disconnect(), secret_line.setText(self.secret_label_text())))
        secret_row.addWidget(secret_pick)
        secret_row.addWidget(secret_disconnect)
        root.addLayout(secret_row)

        buttons = QHBoxLayout()
        buttons.addStretch()
        cancel = ActionButton('İPTAL', 'Grey')
        ok = ActionButton('KAYDET', 'Green')
        buttons.addWidget(cancel)
        buttons.addWidget(ok)
        root.addLayout(buttons)

        def choose_ff():
            f, _ = QFileDialog.getOpenFileName(dlg, 'ffmpeg.exe seç', '', 'FFmpeg (ffmpeg.exe);;Tüm dosyalar (*)')
            if f: ff_edit.setText(f)

        def auto_ff():
            self.log('[Bootstrap] FFmpeg kurulumu deneniyor...')
            f = try_install_ffmpeg_windows()
            if f: ff_edit.setText(f)

        ff_pick.clicked.connect(choose_ff)
        ff_auto.clicked.connect(auto_ff)
        cancel.clicked.connect(dlg.reject)

        def accept():
            self.ffmpeg.setText(ff_edit.text().strip())
            self.maxrate.setText(max_edit.text().strip())
            self.bufsize.setText(buf_edit.text().strip())
            self.logo_w.setValue(logo_width.value())
            self.reencode.setChecked(reencode.isChecked())
            self._check_ffmpeg()
            self.save()
            dlg.accept()

        ok.clicked.connect(accept)
        dlg.exec()

    # ---------- state / settings ----------
    def _load(self):
        resolution = self.s.get('resolution', '1920x1080')
        for i in range(self.res.count()):
            if self.res.itemText(i).startswith(resolution):
                self.res.setCurrentIndex(i)
                break
        self.fps.setCurrentText(str(self.s.get('fps', 30)))
        self.bitrate.setCurrentText(self.s.get('bitrate', '5500k'))
        self.audio_bitrate.setCurrentText(self.s.get('audio_bitrate', '128k'))
        self.maxrate.setText(self.s.get('maxrate', '6500k'))
        self.bufsize.setText(self.s.get('bufsize', '12000k'))
        pos = self.s.get('logo_position', 'top-right')
        idx = self.pos.findData(pos)
        if idx >= 0: self.pos.setCurrentIndex(idx)
        self.logo_w.setValue(self.s.get('logo_width', 220))
        op = float(self.s.get('logo_opacity', .8))
        self.opacity.setValue(op)
        self.opacity_slider.setValue(int(op * 100))
        self.reencode.setChecked(self.s.get('reencode', False))
        self.rtmp.setText(self.s.get('rtmp_manual', ''))
        self.ffmpeg.setText(self.s.get('ffmpeg_path', ''))
        logo_path = self.s.get('logo_path', str(ROOT / 'logo.png'))
        self.logo.setText(logo_path)
        self.logo_toggle.setChecked(bool(self.s.get('logo_enabled', True)))
        self._logo_toggle_changed(self.logo_toggle.isChecked())

    def save(self):
        resolution = self.res.currentText().split(' ', 1)[0]
        d = {
            'ffmpeg_path': self.ffmpeg.text(),
            'resolution': resolution,
            'fps': int(self.fps.currentText()),
            'bitrate': self.bitrate.currentText(),
            'audio_bitrate': self.audio_bitrate.currentText(),
            'maxrate': self.maxrate.text(),
            'bufsize': self.bufsize.text(),
            'logo_width': self.logo_w.value(),
            'logo_opacity': self.opacity_slider.value() / 100.0,
            'logo_position': self.pos.currentData(),
            'logo_enabled': self.logo_toggle.isChecked(),
            'logo_path': self.logo.text(),
            'reencode': self.reencode.isChecked(),
            'rtmp_manual': self.rtmp.text() if self.manual_radio.isChecked() else ''
        }
        save_settings(d)
        self.log('[Ayar] Kaydedildi.')

    def _check_ffmpeg(self):
        f = self.ffmpeg.text().strip() or find_ffmpeg() or ''
        if f:
            self.ffmpeg.setText(f)
            self.sysstatus.set_state('ok', '●  SİSTEM HAZIR')
            self.ffmpeg_footer.setText('●  FFmpeg: Hazır')
            self.ffmpeg_footer.setObjectName('DotOk')
        else:
            self.sysstatus.set_state('bad', '●  FFMPEG EKSİK')
            self.ffmpeg_footer.setText('●  FFmpeg: Eksik')
            self.ffmpeg_footer.setObjectName('DotBad')
        self._repolish(self.ffmpeg_footer)

    def _logo_toggle_changed(self, checked):
        self.pos.setEnabled(checked)
        self.opacity_slider.setEnabled(checked)
        self.logo_info.setText('Yayın logosu dosyası: ' + (Path(self.logo.text()).name if self.logo.text() else 'logo.png') + (' (aktif)' if checked else ' (devre dışı)'))

    def _mode_changed(self):
        self._sync_mode_log()

    def _sync_mode_log(self):
        self.log('[INFO] YouTube modu: ' + ('Otomatik API' if self.api_radio.isChecked() else 'Manuel'))

    def _toggle_rtmp_visibility(self):
        self.rtmp.setEchoMode(QLineEdit.Normal if self.rtmp.echoMode() == QLineEdit.Password else QLineEdit.Password)

    def _repolish(self, widget):
        st = widget.style()
        if st:
            st.unpolish(widget)
            st.polish(widget)
        widget.update()

    # ---------- file pickers ----------
    def pick_logo(self):
        f, _ = QFileDialog.getOpenFileName(self, 'Yayın logosu seç', str(ROOT), 'Görsel (*.png *.jpg *.jpeg *.webp)')
        if f:
            self.logo.setText(f)
            self.logo_info.setText(f'Yayın logosu dosyası: {Path(f).name}')
            self.logo_toggle.setChecked(True)

    def pick_ffmpeg(self):
        f, _ = QFileDialog.getOpenFileName(self, 'ffmpeg.exe seç', '', 'FFmpeg (ffmpeg.exe);;Tüm dosyalar (*)')
        if f:
            self.ffmpeg.setText(f)
            self._check_ffmpeg()

    # ---------- bridge ----------
    def start_bridge(self):
        offer = self.offer.toPlainText().strip()
        rtmp = self.rtmp.text().strip()
        ff = self.ffmpeg.text().strip()
        if not offer or not rtmp or not ff:
            self.warn('Eksik bilgi', 'Offer, RTMP ve FFmpeg alanları zorunlu.')
            return

        resolution = self.res.currentText().split(' ', 1)[0]
        args = [
            '--rtmp', rtmp, '--ffmpeg', ff,
            '--resolution', resolution,
            '--fps', self.fps.currentText(),
            '--bitrate', self.bitrate.currentText(),
            '--maxrate', self.maxrate.text(),
            '--bufsize', self.bufsize.text(),
            '--logo-width', str(self.logo_w.value()),
            '--logo-opacity', str(self.opacity_slider.value() / 100.0),
            '--logo-position', str(self.pos.currentData())
        ]
        logo = self.logo.text().strip()
        if self.logo_toggle.isChecked() and logo and Path(logo).is_file():
            args += ['--logo', logo]
        if self.reencode.isChecked():
            args += ['--reencode']

        try:
            self.bridge.start(sys.executable, args, offer)
            self.save()
            self.youtube_footer.setText('●  YouTube: Başlatılıyor')
            self.youtube_footer.setObjectName('DotOk')
            self._repolish(self.youtube_footer)
        except Exception as exc:
            self.error('Başlatma hatası', str(exc))

    def _answer(self, value):
        self.answer = value
        self.answerbox.setPlainText(value)
        self.wstatus.setText('●  WebRTC: Answer hazır')
        self.wstatus.setObjectName('DotOk')
        self._repolish(self.wstatus)

    def _bridge_state(self, state):
        running = state == 'running'
        self.wstatus.setText('●  WebRTC: Çalışıyor' if running else '●  WebRTC: Bekliyor')
        self.wstatus.setObjectName('DotOk' if running else 'DotIdle')
        self.youtube_footer.setText('●  YouTube: Yayın aktif' if running else '●  YouTube: Bekliyor')
        self.youtube_footer.setObjectName('DotOk' if running else 'DotIdle')
        self._repolish(self.wstatus)
        self._repolish(self.youtube_footer)

    def log(self, text):
        if hasattr(self, 'logbox'):
            self.logbox.append(text)

    # ---------- async YouTube ----------
    def _async(self, fn, ok):
        th = QThread(self)
        worker = Worker(fn)
        worker.moveToThread(th)
        th.started.connect(worker.run)
        worker.done.connect(ok)
        worker.done.connect(th.quit)
        worker.fail.connect(lambda e: (self.log('[YouTube Hata] ' + e), self.error('YouTube', e)))
        worker.fail.connect(th.quit)
        th.finished.connect(worker.deleteLater)
        th.finished.connect(th.deleteLater)
        th.start()
        self._thread = th

    def secret_label_text(self):
        if SECRET.is_file():
            return 'client_secret.json: HAZIR' + (' • OAuth kayıtlı' if TOKEN.is_file() else '')
        return 'client_secret.json: BULUNAMADI'

    def _refresh_secret_state(self):
        pass

    def pick_client_secret(self):
        import json, shutil
        f, _ = QFileDialog.getOpenFileName(self, 'YouTube client_secret.json seç', str(ROOT), 'JSON (*.json)')
        if not f:
            return
        try:
            data = json.loads(Path(f).read_text(encoding='utf-8'))
            if not isinstance(data, dict) or not ('installed' in data or 'web' in data):
                raise ValueError('Geçerli Google OAuth client JSON formatı değil.')
            shutil.copy2(f, SECRET)
            self.log('[YouTube] client_secret.json proje köküne kopyalandı.')
        except Exception as exc:
            self.error('client_secret.json', str(exc))

    def youtube_disconnect(self):
        disconnect()
        self.yt = None
        self.ytstatus.setText('Bağlı değil')
        self.ytstatus.setObjectName('DangerText')
        self._repolish(self.ytstatus)
        self.log('[YouTube] Yerel OAuth token silindi.')

    def youtube_connect(self):
        self._async(lambda: (YouTubeLive(True),), lambda r: self._youtube_connected(r[0]))

    def _youtube_connected(self, yt):
        self.yt = yt
        ch = yt.channel()
        self.ytstatus.setText('Bağlı: ' + ch['title'])
        self.ytstatus.setObjectName('DotOk')
        self._repolish(self.ytstatus)
        self.api_radio.setChecked(True)
        self.log('[YouTube] Hesap bağlandı: ' + ch['title'])

    def youtube_fetch(self):
        def fn():
            y = self.yt or YouTubeLive(True)
            streams = y.list_streams()
            return y, streams

        def ok(result):
            self.yt = result[0]
            items = result[1]
            if not items:
                self.info('YouTube', 'Mevcut stream bulunamadı. Yeni yayın oluşturabilirsiniz.')
                return
            labels = [f"{x['title']} [{x['status']}]" for x in items]
            choice, yes = QInputDialog.getItem(self, 'YouTube Stream', 'Stream seçin:', labels, 0, False)
            if yes:
                x = items[labels.index(choice)]
                self.rtmp.setText(x['rtmp_url'])
                self.api_radio.setChecked(True)
                self.log('[YouTube] RTMP bilgisi alındı (key logda gizlidir).')

        self._async(fn, ok)

    def youtube_create(self):
        title, ok = QInputDialog.getText(self, 'Yeni YouTube Yayını', 'Yayın başlığı:')
        if not ok or not title.strip():
            return
        privacy, ok = QInputDialog.getItem(self, 'Gizlilik', 'Gizlilik:', ['unlisted', 'private', 'public'], 0, False)
        if not ok:
            return
        resolution = {'1920x1080': '1080p', '1280x720': '720p', '854x480': '480p'}[self.res.currentText().split(' ', 1)[0]]
        fps = '60fps' if self.fps.currentText() == '60' else '30fps'

        def fn():
            y = self.yt or YouTubeLive(True)
            return y, y.create_broadcast_and_stream(title.strip(), privacy=privacy, resolution=resolution, fps=fps)

        def done(result):
            self.yt = result[0]
            self.rtmp.setText(result[1]['stream']['rtmp_url'])
            self.api_radio.setChecked(True)
            self.ytstatus.setText('Yayın oluşturuldu')
            self.ytstatus.setObjectName('DotOk')
            self._repolish(self.ytstatus)
            self.log('[YouTube] Broadcast + stream oluşturuldu ve bind edildi.')

        self._async(fn, done)

    def closeEvent(self, event):
        self.bridge.stop()
        self.save()
        event.accept()
